class Graph:
    def __init__(self):
        self._ids = {}

    def add_user(self, id):
        if id not in self._ids.keys():
            self._ids[id] = set()

    def add_friendship(self, user, friend):
        self._ids[user] =  self._ids[user] | {friend}
        self._ids[friend] = self._ids[friend] | {user}

    def remove_user(self, id):
        if id in self._ids.keys():
            self._ids.pop(id)
            for i in self._ids.keys():
                if id in self._ids[i]:
                    self._ids[i].remove(id)

    def remove_friendship(self, key, value):
        spare_value = self._ids[key]
        spare_value.remove(value)
        self._ids[key] = spare_value
        spare_value = self._ids[value]
        spare_value.remove(key)
        self._ids[value] = spare_value

    def users(self):
        return self._ids.keys()

    def friendships(self):
        return self._ids.values()

    def friends_for(self, id):
        return self._ids[id]

    @staticmethod
    def is_consistent(template):
        consistent = True
        missing = set()
        for i in template.keys():
            for j in template[i]:
                if not i in template[j]:
                    consistent = False
                    missing.add({i,j})
        return consistent