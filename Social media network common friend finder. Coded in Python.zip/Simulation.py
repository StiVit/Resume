from os.path import exists
from Social_Network import SocialNetwork

class Simulation:
    def __init__(self):
        self._social_network = SocialNetwork()

    def add_from_file_to_the_social_network(self, line):
        try:
            if len(line) == 2:
                self._social_network.add_user(line[0])
                self._social_network.add_user(line[1])
                self._social_network.add_friendship(line[0], line[1])
            elif len(line) == 1:
                self._social_network.add_user(line[0])
            else:
                raise ValueError()
        except ValueError:
            print("invalid input from the file:")
            self._social_network._ids = {}
            self.reading_from_file()

    def reading_from_file(self):
        file_path = input("enter a filename for network data: ")
        if file_path != 'n':
            if exists(file_path) == False:
                print('unexistent file')
                self.reading_from_file()
            f = open(file_path, "r+")
            self._number_of_users = int(f.readline())
            while True:
                line = f.readline()
                if not line:
                    f.close()
                    break
                line = line.split()
                if len(self._social_network._ids.keys()) == self._number_of_users and line[0] not in self._social_network._ids.keys():
                    break
                self.add_from_file_to_the_social_network(line)
            if not self._social_network.is_consistent(self._social_network._ids):
                print('not consistent, try again')
                self.reading_from_file()
            f.close()

    def writing_the_social_network(self):
        if input("Would you like to see the social network created: y/n? ") == 'y':
            print(self._social_network)

    def least_number_of_friends(self):
        if input("would you like to see the user with the least number of friends and the people with 0 friends: y/n:") == 'y':
            minn = float('inf')
            for i in self._social_network._ids.keys():
                if len(self._social_network._ids[i]) < minn and len(self._social_network._ids[i]) != 0:
                    minn = len(self._social_network._ids[i])
            print(f'users with the minimum number of friends ({minn}): ')
            for i in self._social_network._ids.keys():
                if len(self._social_network._ids[i]) == minn:
                    print(i)
            print("users with 0 friends: ")
            for i in self._social_network._ids.keys():
                if len(self._social_network._ids[i]) == 0:
                    print(i)

    def common_friends_count(self):
        common_friends = [[0 for _ in range(self._number_of_users)] for _ in range(self._number_of_users)]
        index_row = 0
        for i in self._social_network._ids.keys():
            index_col = 0
            for j in self._social_network._ids.keys():
                common_friends[index_row][index_col] = len(self._social_network._ids[i].intersection(self._social_network._ids[j]))
                index_col += 1
            index_row += 1
        return common_friends

    def get_recommendation(self):
        if input('would you like to get the recommendation for some users: y/n: ') == 'y':
            allowed_recommendation = True
        else:
            allowed_recommendation = False
        while allowed_recommendation:
            print(self._social_network.recommended_friend(input('introduce the id for whom you would like to see a recommendation: ')))
            if input("Would you like to see another user's recommendation?: y/n: ") == 'n':
                allowed_recommendation = False

    def friends_of_friends(self):
        if input("Would you like to see the friends of the friends of each user?: y/n: ") == 'y':
            result = {}
            for i in self._social_network._ids.keys():
                result[i] = self._social_network.deep_search_of_friends(i)
            representation = ''
            for i in result.keys():
                representation += f"{i} -> " + ', '.join(map(str, result[i])) + '\n'
            print(representation)

    def number_of_friends(self):
        if input('would you like to see the number of friends of a user?: y/n: ') == 'y':
            id = input('who\'s friends would you like to see? ')
            if not id in self._social_network._ids.keys():
                print('invalid user')
            else:
                print(len(self._social_network.friends_for(id)))