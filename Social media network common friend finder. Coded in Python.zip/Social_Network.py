from Graph import Graph

class SocialNetwork(Graph):

    def __init__(self):
        super(SocialNetwork, self).__init__()

    def common_friends_between(self, id1, id2):
        return self._ids[id1].intersection(self._ids[id2])

    def recommended_friend(self, id):
        maxx = 0
        result = id
        for i in self._ids.keys():
            if i != id:
                if len(self.common_friends_between(i, id)) > maxx:
                    result = i
                    maxx = len(self.common_friends_between(i, id))
        if result == id:
            return "this user doesn't have any recommendations"
        else:
            return result

    def __str__(self):
        result = ''
        for i in self._ids.keys():
            result += f"{i} -> " +  ', '.join(map(str, self._ids[i])) + '\n'
        return result

    def deep_search_of_friends(self, id):
        friends = set()
        for i in self._ids[id]:
            for j in self._ids[i]:
                if j != id:
                    friends.add(j)
        return friends

