from Simulation import Simulation

if __name__ == "__main__":
    # additional tests Tests/info1.txt
    new_file = True
    while new_file == True:
        social_NW = Simulation()
        social_NW.reading_from_file()
        social_NW.writing_the_social_network()
        social_NW.least_number_of_friends()
        social_NW.get_recommendation()
        social_NW.number_of_friends()

        if input('would you like to see the friends of a user?: y/n: ') == 'y':
            id = input("who's friends you would like to see? ")
            if not id in social_NW._social_network._ids.keys():
                print('invalid user')
            else:
                print(social_NW._social_network.friends_for(id))

        if input("would you like to see the common friends between users in form of a matrix: y/n: ") == 'y':
            common_friends = social_NW.common_friends_count()
            users = list(social_NW._social_network.users())
            for i in range(social_NW._number_of_users):
                print(f'{users[i]} -> {common_friends[i]}')

        social_NW.friends_of_friends()

        if input('would you like to try a new file : y/n: ') == 'n':
            new_file = False