# Markov Chain Composer
Using Markov Chain to represent relationships between words in song lyrics and then generating new lyrics.. *ahem* interpretive poetry... from the graph

To run: `python3 compose.py`

You'll have to slightly change some of the code in order to adjust length of composition/which file is the vocabulary for the composition.

YouTube Kylie Ying: https://www.youtube.com/ycubed 
Twitch KylieYing: https://www.twitch.tv/kylieying 
Twitter @kylieyying: https://twitter.com/kylieyying 
Instagram @kylieyying: https://www.instagram.com/kylieyying/ 
Website: https://www.kylieying.com
Github: https://www.github.com/kying18 
Programmer Beast Mode Spotify playlist: https://open.spotify.com/playlist/4Akns5EUb3gzmlXIdsJkPs?si=qGc4ubKRRYmPHAJAIrCxVQ 